package com.arukione.curriculum_design.model.VO;

import lombok.Data;

@Data
public class ApplicationStatusInfo {
    String TopicName;
    String SName;
    String ApplyTime;
    String Status;
    String Source;
}
