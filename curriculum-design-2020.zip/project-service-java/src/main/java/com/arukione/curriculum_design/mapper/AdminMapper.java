package com.arukione.curriculum_design.mapper;

import com.arukione.curriculum_design.model.entity.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminMapper extends BaseMapper<Admin> {

}

