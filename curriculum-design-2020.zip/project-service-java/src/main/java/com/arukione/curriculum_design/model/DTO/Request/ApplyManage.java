package com.arukione.curriculum_design.model.DTO.Request;

import lombok.Data;

@Data
public class ApplyManage {
    String sid;
    String topicId;
    String status;
}
