package com.arukione.curriculum_design.model.VO;

import lombok.Data;

@Data
public class GuideStudentInfo {
    String SName;
    String SID;
    String DeptName;
    String ProfName;
    String ClassNumber;
    String Grade;
    String TopicName;
}
