package com.arukione.curriculum_design.model.DTO.Request;

import lombok.Data;

@Data
public class TopicInfo {
    String topicName;
    String typeId;
    String introduction;
}
