package com.arukione.curriculum_design.model.VO;

import lombok.Data;

@Data
public class TopicView {
    String TopicID;
    String TopicName;
    String Introduction;
    String Type;
    String SID;
    String SName;
    String Source;
}
