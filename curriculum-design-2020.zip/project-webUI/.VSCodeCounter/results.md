# Summary

Date : 2020-06-17 18:31:21

Directory h:\Code Files\GitHub\curriculum-design-2020\project-webUI\src

Total : 21 files,  3389 codes, 0 comments, 80 blanks, all 3469 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Vue | 19 | 3,349 | 0 | 72 | 3,421 |
| JavaScript | 2 | 40 | 0 | 8 | 48 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 21 | 3,389 | 0 | 80 | 3,469 |
| components | 16 | 2,808 | 0 | 42 | 2,850 |
| router | 1 | 26 | 0 | 5 | 31 |
| views | 2 | 484 | 0 | 28 | 512 |

[details](details.md)