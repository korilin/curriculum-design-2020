# Details

Date : 2020-06-17 18:31:20

Directory h:\Code Files\GitHub\curriculum-design-2020\project-webUI\src

Total : 21 files,  3389 codes, 0 comments, 80 blanks, all 3469 lines

[summary](results.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [src/App.vue](/src/App.vue) | Vue | 57 | 0 | 2 | 59 |
| [src/components/accountManage.vue](/src/components/accountManage.vue) | Vue | 549 | 0 | 3 | 552 |
| [src/components/addStudent.vue](/src/components/addStudent.vue) | Vue | 174 | 0 | 2 | 176 |
| [src/components/addTeacher.vue](/src/components/addTeacher.vue) | Vue | 181 | 0 | 2 | 183 |
| [src/components/addTopic.vue](/src/components/addTopic.vue) | Vue | 137 | 0 | 3 | 140 |
| [src/components/allTeacher.vue](/src/components/allTeacher.vue) | Vue | 94 | 0 | 2 | 96 |
| [src/components/allTopic.vue](/src/components/allTopic.vue) | Vue | 86 | 0 | 2 | 88 |
| [src/components/applyManage.vue](/src/components/applyManage.vue) | Vue | 234 | 0 | 2 | 236 |
| [src/components/applyManageRecord.vue](/src/components/applyManageRecord.vue) | Vue | 89 | 0 | 2 | 91 |
| [src/components/applyRecord.vue](/src/components/applyRecord.vue) | Vue | 93 | 0 | 2 | 95 |
| [src/components/guideStudents.vue](/src/components/guideStudents.vue) | Vue | 91 | 0 | 3 | 94 |
| [src/components/myTeacher.vue](/src/components/myTeacher.vue) | Vue | 95 | 0 | 2 | 97 |
| [src/components/myTopic.vue](/src/components/myTopic.vue) | Vue | 95 | 0 | 2 | 97 |
| [src/components/studentTopicApply.vue](/src/components/studentTopicApply.vue) | Vue | 182 | 0 | 3 | 185 |
| [src/components/teacherTopicApply.vue](/src/components/teacherTopicApply.vue) | Vue | 146 | 0 | 3 | 149 |
| [src/components/topicManage.vue](/src/components/topicManage.vue) | Vue | 241 | 0 | 2 | 243 |
| [src/components/userInfo.vue](/src/components/userInfo.vue) | Vue | 321 | 0 | 7 | 328 |
| [src/main.js](/src/main.js) | JavaScript | 14 | 0 | 3 | 17 |
| [src/router/index.js](/src/router/index.js) | JavaScript | 26 | 0 | 5 | 31 |
| [src/views/login.vue](/src/views/login.vue) | Vue | 208 | 0 | 4 | 212 |
| [src/views/main.vue](/src/views/main.vue) | Vue | 276 | 0 | 24 | 300 |

[summary](results.md)